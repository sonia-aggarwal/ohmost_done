#include "PortPins.h"

void InitializePortPin(GPIOPortPin *PortPin,
                       unsigned char *PortRegister,
                       unsigned char *DirectionRegister,
                       unsigned char BitPosition, GPIODirection Direction)
{
    PortPin->PortRegister = PortRegister;
    PortPin->DirectionRegister = DirectionRegister;
    PortPin->BitPosition = BitPosition;

    if (Direction == Output) {

        // Initialize port pin value to 0, and configure port pin as an output.
        *(PortPin->PortRegister) &= ~(0x01 << PortPin->BitPosition);
        *(PortPin->DirectionRegister) |= (0x01 << PortPin->BitPosition);
    }
    else {

        // Configure port pin as an input.
        *(PortPin->DirectionRegister) &= ~(0x01 << PortPin->BitPosition);
    }
}

unsigned char DigitalReadPortPin(GPIOPortPin *PortPin)
{
    unsigned char ReadValue;

    // First, perform bit-masking at the appropriate bit location.
    ReadValue = *(PortPin->PortRegister) & (0x01 << PortPin->BitPosition);

    // Then, right-shift so that the return value is either 0 or 1.
    ReadValue = ReadValue >> (PortPin->BitPosition);

    return ReadValue;
}

void DigitalWritePortPin(GPIOPortPin *PortPin, unsigned char OutputValue)
{
    if (OutputValue == 0){
        *(PortPin->PortRegister) &= ~(0x01 << PortPin->BitPosition);
    }
    else {
        *(PortPin->PortRegister) |= (0x01 << PortPin->BitPosition);
    }
}

