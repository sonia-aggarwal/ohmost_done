#include <msp430.h>
#include "SoilMoisture.h"
#include "PortPins.h"


// Global Variables
GPIOPortPin SoilMoisture1;
#define FALSE 0
#define TRUE 1

// Function Prototypes
void ConfigureClockModule();

int main(void)
{

    WDTCTL = WDTPW | WDTHOLD;       // Stop watchdog timer
    ConfigureClockModule();

    // Initialize hardware.
    InitializeSoilMoisture1PortPin();

    // Loop forever
    while(TRUE) {

        // Read current input.
        SoilMositure1Input = DigitalReadPortPin(&SoilMoisture1);

    }
    return 0;
}

void ConfigureClockModule()
{
    // Configure Digitally Controlled Oscillator (DCO) using factory calibrations
    DCOCTL  = CALDCO_1MHZ;
    BCSCTL1 = CALBC1_1MHZ;
}
