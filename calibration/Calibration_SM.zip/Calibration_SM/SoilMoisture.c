#include "SoilMoisture.h"
extern GPIOPortPin SoilMoisture1;
/*
 * SoilMoisture.c
 *
 *  Created on: Oct 16, 2020
 *      Author: Victoria Nilsson
 */

void InitializeSoilMoisture1PortPin (void)
{
    // Configure port pin for SoilMoisture1
    ENABLE_PULL_UP_PULL_DOWN_RESISTORS;
    SELECT_PULL_UP_RESISTORS;
    InitializePortPin(&SoilMoisture1,
                      (unsigned char *)&SOIL_MOIST_1_PORT_IN ,
                      (unsigned char *)&SOIL_MOIST_1_DDR ,
                      SOIL_MOIST_1_PIN,Input);

}



