#ifndef PORTPINS_H_
#define PORTPINS_H_

#include <msp430.h>

typedef enum {Input, Output} GPIODirection;

typedef struct {
    unsigned char *PortRegister;
    unsigned char *DirectionRegister;
    unsigned char BitPosition;
} GPIOPortPin;


// Prototypes
void InitializePortPin(GPIOPortPin *PortPin,
                       unsigned char *PortRegister,
                       unsigned char *DirectionRegister,
                       unsigned char BitPosition,
                       GPIODirection Direction);
unsigned char DigitalReadPortPin(GPIOPortPin *PortPin);
void DigitalWritePortPin(GPIOPortPin *PortPin, unsigned char OutputValue);

#endif /* PORTPINS_H_ */
