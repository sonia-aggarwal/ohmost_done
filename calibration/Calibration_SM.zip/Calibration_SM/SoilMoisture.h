/*
 * SoilMoisture.h
 *
 *  Created on: Oct 16, 2020
 *      Author: Victoria Nilsson
 */

#ifndef SOILMOISTURE_H_
#define SOILMOISTURE_H_
//Soil Moisture #1
#define SOIL_MOIST_1_PIN                      0
#define SOIL_MOIST_1_BIT                      BIT0    // Port pin bit location for pushbutton
#define SOIL_MOIST_1_REN                      P6REN   // Register to enable resistors for pushbutton
#define SOIL_MOIST_1_PORT_IN                  P6IN    // Register to read port pin input
#define SOIL_MOIST_1_PORT                     P6OUT   // Register to select pull-up/pull-down
#define SOIL_MOIST_1_DDR                      P6DIR   // Data Direction Register (DDR) for pushbutton.
#define ENABLE_PULL_UP_PULL_DOWN_RESISTORS  PUSHBUTTON_REN |= PUSHBUTTON_BIT
#define SELECT_PULL_UP_RESISTORS            PUSHBUTTON_PORT |= PUSHBUTTON_BIT

// Prototypes
void InitializeSoilMoisture1PortPin(void);

#endif /* SOILMOISTURE_H_ */
